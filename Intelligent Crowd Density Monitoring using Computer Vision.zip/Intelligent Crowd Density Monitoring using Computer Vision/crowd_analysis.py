from ultralytics import YOLO
import cv2
import winsound

# Load YOLOv8 model
model = YOLO("yolov8n.pt")


def analyze_crowd(image_path):

    image = cv2.imread(image_path)

    results = model(image)

    count = 0

    # Detect persons
    for r in results:
        boxes = r.boxes

        for box in boxes:

            cls = int(box.cls[0])

            # Class 0 = Person
            if cls == 0:

                count += 1

                x1, y1, x2, y2 = map(int, box.xyxy[0])

                cv2.rectangle(
                    image,
                    (x1, y1),
                    (x2, y2),
                    (0, 255, 0),
                    2
                )

                cv2.putText(
                    image,
                    "Person",
                    (x1, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 0),
                    2
                )

    # Display total persons
    cv2.putText(
        image,
        f"Total Persons: {count}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0, 0, 255),
        3
    )

    # Alert if crowd is more than 10 people
    if count > 10:

        cv2.putText(
            image,
            "HIGH CROWD DENSITY!",
            (20, 80),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 0, 255),
            3
        )

        # Play beep sound
        winsound.Beep(1500, 1000)

    # Save output image
    result_path = "static/results/output.jpg"
    cv2.imwrite(result_path, image)

    return count, result_path