from flask import Flask, render_template, request, Response
from crowd_analysis import analyze_crowd
from ultralytics import YOLO
import cv2
import os
import winsound
import time

app = Flask(__name__)

UPLOAD_FOLDER = "static/uploads"
RESULT_FOLDER = "static/results"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

# YOLO Model
model = YOLO("yolov8n.pt")

# Alarm timer
last_alarm = 0


@app.route('/')
def signin():
    return render_template('signin.html')


@app.route('/signup')
def signup():
    return render_template('signup.html')


@app.route('/home')
def home():
    return render_template('home.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/stream')
def stream():
    return render_template('stream.html')


@app.route('/detection', methods=['GET', 'POST'])
def detection():

    if request.method == 'POST':

        file = request.files['image']

        if file:

            filepath = os.path.join(
                UPLOAD_FOLDER,
                file.filename
            )

            file.save(filepath)

            count, result_path = analyze_crowd(filepath)

            return render_template(
                'detection.html',
                count=count,
                result_image=result_path
            )

    return render_template('detection.html')


# LIVE WEBCAM DETECTION

def generate_frames():

    global last_alarm

    camera = cv2.VideoCapture(0)

    while True:

        success, frame = camera.read()

        if not success:
            break

        results = model(frame)

        count = 0

        for r in results:

            for box in r.boxes:

                if int(box.cls[0]) == 0:

                    count += 1

                    x1, y1, x2, y2 = map(
                        int,
                        box.xyxy[0]
                    )

                    cv2.rectangle(
                        frame,
                        (x1, y1),
                        (x2, y2),
                        (0, 255, 0),
                        2
                    )

        # Display person count
        cv2.putText(
            frame,
            f"Persons: {count}",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 0, 255),
            2
        )

        # High crowd warning
        if count > 10:

            cv2.putText(
                frame,
                "HIGH CROWD DENSITY!",
                (20, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 0, 255),
                3
            )

            # Beep once every 3 seconds
            if time.time() - last_alarm > 3:
                winsound.Beep(1500, 700)
                last_alarm = time.time()

        ret, buffer = cv2.imencode('.jpg', frame)

        frame = buffer.tobytes()

        yield (
            b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n'
            + frame +
            b'\r\n'
        )


@app.route('/video_feed')
def video_feed():

    return Response(
        generate_frames(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


if __name__ == '__main__':
    app.run(debug=True)